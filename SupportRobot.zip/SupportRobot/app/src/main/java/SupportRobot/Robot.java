package SupportRobot;

import xapi.xapiServer;
import PrinterAnimation.PrinterAnimation;
import LXJSON.LXJSON;
import java.util.Scanner;

public class Robot {

    public static void main(String[] args) {
        
        String username = ""; //Enter username account in xapi #LeoxDev
        String password = ""; //Enter password account in xapi #LeoxDev
        String nameBot = "LXbot"; //The name of the robot you want to talk to.
        
        Scanner scan = new Scanner(System.in);
        PrinterAnimation p = new PrinterAnimation(10);
        xapiServer server = new xapiServer(username , password);
        p.print("Hello What can this robot do? : " + LXJSON.readValueOfKey(server.getData(nameBot , "json") , "welcomTXT"));
        p.print("start");
        while(true){
            String input = scan.nextLine();
            p.print(LXJSON.readValueOfKey(server.getData(nameBot , "json") , input));
        }
    }
}