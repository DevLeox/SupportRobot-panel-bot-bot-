package pma.SupportRobot;

import xapi.xapiServer;
import PrinterAnimation.PrinterAnimation;
import LXJSON.LXJSON;
import java.util.Scanner;

public class PanelMyAdmin {

    public static void main(String[] args) {
        
        String username = ""; //Enter username account in xapi #LeoxDev
        String password = ""; //Enter password account in xapi #LeoxDev
        
        PrinterAnimation p = new PrinterAnimation(10);
        Scanner scanInput = new Scanner(System.in);
        Scanner scanBot = new Scanner(System.in);
        Scanner scanOrderA = new Scanner(System.in);
        Scanner scanOrderAC = new Scanner(System.in);
        Scanner scanOrderR = new Scanner(System.in);
        xapiServer server = new xapiServer(username , password);
        p.print("hello welcome to the RobotMyAdmin.");
        System.out.println();
        p.print("1_create robot");
        p.print("2_delete robot");
        p.print("3_add / edit order");
        p.print("4_remove order");
        System.out.println();
        p.print("which one do you like.");
        while(true){
            int input = scanInput.nextInt();
            p.print("----------------------------------");
            switch(input){
                case 1 :
                    p.print("Enter name bot : ");
                    String usernameBotC = scanBot.nextLine();
                    server.create(usernameBotC , password , "json");
                    server.edit(usernameBotC , password , "{}" , "json");
                    server.edit(usernameBotC , password , LXJSON.putKey(server.getData(usernameBotC , "json") , "welcomeTXT" , "") , "json");
                    p.print("Robot created. please check your xapi`s account");
                    p.print("Usernme Bot : " + usernameBotC);
                    p.print("Password Bot : " + password);
                    p.print("----------------------------------");
                break;
                case 2 :
                    p.print("Enter name bot : ");
                    String usernameBotD = scanBot.nextLine();
                    server.delete(usernameBotD , password , "json");
                    p.print("Robot delete.");
                    p.print("----------------------------------");
                break;
                case 3 :
                    p.print("Enter name bot : ");
                    String botnameA = scanOrderAC.nextLine();
                    p.print("Enter key order bot : ");
                    String keyA = scanOrderA.nextLine();
                    p.print("Enter value order bot : ");
                    String valueA = scanOrderA.nextLine();
                    server.edit(botnameA , password , LXJSON.putKey(server.getData(botnameA , "json") , keyA , valueA) , "json");
                    p.print("key robot edited / added");
                    p.print("----------------------------------");
                break;
                case 4 :
                    p.print("Enter name bot : ");
                    String botnameR = scanOrderAC.nextLine();
                    p.print("Enter key order bot : ");
                    String keyR = scanOrderR.nextLine();
                    server.edit(botnameR , password , LXJSON.deleteKey(server.getData(botnameR , "json") , keyR) , "json");
                    p.print("key order bot deleted");
                    p.print("----------------------------------");
                break;
            }
        }
   }
}
